<?php

namespace App\Http\Livewire\Leccion;

use Livewire\Component;

class Index extends Component
{
    public function render()
    {
        return view('livewire.leccion.index');
    }
}
