

 <div class="row">

    @include("livewire.alumno.$view")

    @include("livewire.alumno.table")
 </div>



