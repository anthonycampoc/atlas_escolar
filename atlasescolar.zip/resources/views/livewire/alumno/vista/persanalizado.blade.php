<div class="row">

    @include("livewire.alumno.vista.informacion")
    @include("livewire.alumno.vista.$view")

</div>
