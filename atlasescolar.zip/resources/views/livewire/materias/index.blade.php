

 <div class="row">
    
   
    @include("livewire.materias.$view")

    @include("livewire.materias.table")
 </div>



