

 <div class="row">

    @include("livewire.profesor.$view")

    @include("livewire.profesor.table")
 </div>



