<div class="row">
    <div class="col">
    <input type="text" wire:model= "titulo" name="name" class="form-control" placeholder="Titulo" aria-label="Nombre">
    </div>
    <div class="col">
    <input type="text" wire:model = "contenido" name="last_name" class="form-control" placeholder="Contenido" aria-label="Descripcion">
    </div>
</div> 