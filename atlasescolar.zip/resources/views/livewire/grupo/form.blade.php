<div class="card-body">
    <div class="row">
        <div class="col">
          <input type="text" wire:model= "number" name="number" class="form-control" placeholder="Numero Curso" aria-label="Nombre">
        </div>
        <div class="col">
          <input type="text" wire:model = "name" name="name" class="form-control" placeholder="Nombre" aria-label="Descripcion">
        </div>
        <div class="col">
          <input type="text" wire:model = "schedule" name="number" class="form-control" placeholder="Calendario" aria-label="Descripcion">
        </div>
    </div> 
    <div class="row mt-3">
      <div class="col">
        <input type="text" wire:model= "description" name="telephone" class="form-control" placeholder="Descripcion" aria-label="Nombre">
      </div>

      
  </div> 
</div>