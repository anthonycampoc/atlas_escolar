<?php return array (
  'alumno.index' => 'App\\Http\\Livewire\\Alumno\\Index',
  'alumno.vista.persanalizado' => 'App\\Http\\Livewire\\Alumno\\Vista\\Persanalizado',
  'grupo.asignacion.index' => 'App\\Http\\Livewire\\Grupo\\Asignacion\\Index',
  'grupo.index' => 'App\\Http\\Livewire\\Grupo\\Index',
  'leccion.index' => 'App\\Http\\Livewire\\Leccion\\Index',
  'materias.index' => 'App\\Http\\Livewire\\Materias\\Index',
  'profesor.index' => 'App\\Http\\Livewire\\Profesor\\Index',
);