

<?php $__env->startSection('title', 'Dashboard'); ?>

<?php $__env->startSection('content_header'); ?>
  <hr>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
       
        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('leccion.index')->html();
} elseif ($_instance->childHasBeenRendered('r2lxWwX')) {
    $componentId = $_instance->getRenderedChildComponentId('r2lxWwX');
    $componentTag = $_instance->getRenderedChildComponentTagName('r2lxWwX');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('r2lxWwX');
} else {
    $response = \Livewire\Livewire::mount('leccion.index');
    $html = $response->html();
    $_instance->logRenderedChild('r2lxWwX', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?> 
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="/css/admin_custom.css">
    <?php echo \Livewire\Livewire::styles(); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script> console.log('Hi!'); </script>
    <?php echo \Livewire\Livewire::scripts(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\atlasescolar\resources\views/admin/leccion/index.blade.php ENDPATH**/ ?>