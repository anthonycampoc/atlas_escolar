

<?php $__env->startSection('title', 'Vista Alumno'); ?>

<?php $__env->startSection('content_header'); ?>

<hr>
<?php $config = (new \LaravelPWA\Services\ManifestService)->generate(); echo $__env->make( 'laravelpwa::meta' , ['config' => $config])->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('alumno.vista.persanalizado', ['idgrado'=>$idnumber])->html();
} elseif ($_instance->childHasBeenRendered('ePWhajp')) {
    $componentId = $_instance->getRenderedChildComponentId('ePWhajp');
    $componentTag = $_instance->getRenderedChildComponentTagName('ePWhajp');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('ePWhajp');
} else {
    $response = \Livewire\Livewire::mount('alumno.vista.persanalizado', ['idgrado'=>$idnumber]);
    $html = $response->html();
    $_instance->logRenderedChild('ePWhajp', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?> 
   
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="/css/admin_custom.css">
    <?php echo \Livewire\Livewire::styles(); ?>

<?php $__env->stopSection(); ?>
    <?php echo \Livewire\Livewire::scripts(); ?>

<?php $__env->startSection('js'); ?>

    <script> console.log('Hi!'); </script>
   
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\atlasescolar\resources\views/admin/alumno/show.blade.php ENDPATH**/ ?>