

<?php $__env->startSection('title', 'Panel Alumno'); ?>

<?php $__env->startSection('content_header'); ?>

    <h1 class="text-center text-info "> <strong> Panel administrador</strong></h1>
    <?php $config = (new \LaravelPWA\Services\ManifestService)->generate(); echo $__env->make( 'laravelpwa::meta' , ['config' => $config])->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('alumno-edit')): ?>
<section class="content">
    <div class="container-fluid">
        <div class="row">

       
              
        <?php $__currentLoopData = $UserAlumno; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($item->codigo == $idnumber): ?>
                    <div class="col-6">
                        <div class="card card-primary">
                            <div class="row  align-items-center">
                                <div class="card-body">
                                    <div class="row">
                                        <div class="col">
                                            
                                                    <h3 class="text-center text-warning " > <a href="<?php echo e(route('alumno.show' , $item->idcurso)); ?>"><strong><?php echo e($item->cursoNombre); ?></strong></a>   </h3>
                                        
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

         
    
        </div>
    </div>
</section>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="/css/admin_custom.css">
    <?php echo \Livewire\Livewire::styles(); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <?php echo \Livewire\Livewire::scripts(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\atlasescolar\resources\views/admin/alumno/home.blade.php ENDPATH**/ ?>