

<?php $__env->startSection('title', 'Roles'); ?>

<?php $__env->startSection('content_header'); ?>
<?php $config = (new \LaravelPWA\Services\ManifestService)->generate(); echo $__env->make( 'laravelpwa::meta' , ['config' => $config])->render(); ?>
<section class="content-header">
    <div class="container-fluid">
        <div class="row mb-2">
            <div class="col-sm-6">
                <h1>Roles</h1>
            </div>
            <div class="col-sm-6">
                <ol class="breadcrumb float-sm-right">
                    <li class="breadcrumb-item"><a href="<?php echo e(route('home')); ?>">Inicio</a></li>
                    <li class="breadcrumb-item active">Roles</li>
                </ol>
            </div>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('role-index')): ?>
<section class="content">
    <div class="container-fluid">
        <div class="row">

           

            <div class="col-12">
                <div class="card card-primary">
                    <div class="row  align-items-center">
                        <div class="col-8">
                            <a href="<?php echo e(route('roles.create')); ?>" class="btn btn-info ml-2 mt-2 mb-2"> <i
                                    class="far fa-plus-square"></i> Nuevo rol</a>


                        </div>
                        <div class="col-4">

                            <div class="input-group float-rigth mr-2  mt-2 mb-2">
                                <input type="text" class="form-control" placeholder="Buscar"
                                    aria-label="Recipient's username" aria-describedby="basic-addon2">
                                <div class="input-group-append">
                                    <button class="btn btn-outline-secondary" type="button">
                                        <i class="fas fa-search"></i>
                                    </button>
                                </div>
                            </div>

                        </div>

                    </div>

                </div>
            </div>


            <div class="col-12">
                <div class="card card-primary">
                    <div class="card-body">

                        <div class="table-responsive">
                            <table class="table table-bordered">

                                <thead>
                                    <tr>
                                        <th>Nro</th>
                                        <th>Nombre</th>
                                        <th width="280px">Acción</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e(++$i); ?></td>
                                        <td><?php echo e($role->name); ?></td>
                                        <td>
                                            <a class="btn btn-info"
                                                href="<?php echo e(route('roles.show',$role->id)); ?>">Mostrar</a>
                                           
                                            <a class="btn btn-primary"
                                                href="<?php echo e(route('roles.edit',$role->id)); ?>">Editar</a>
                                        
                                         
                                            <?php echo Form::open(['method' => 'DELETE','route' => ['roles.destroy',
                                            $role->id],'style'=>'display:inline']); ?>

                                            <?php echo Form::submit('Eliminar', ['class' => 'btn btn-danger']); ?>

                                            <?php echo Form::close(); ?>

                                       
                                        </td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>

                    </div>
                    <div class="card-footer clearfix">

                        <?php echo $roles->render(); ?>


                    </div>
                </div>
            </div>
        </div>
    </div>
<?php endif; ?>    
</section>


<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
<link rel="stylesheet" href="/css/admin_custom.css">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<script>
    console.log('Hi!');

</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\atlasescolar\resources\views/roles/index.blade.php ENDPATH**/ ?>