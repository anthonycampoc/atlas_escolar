

<?php $__env->startSection('title', 'Materias'); ?>

<?php $__env->startSection('content_header'); ?>
  <hr>
  <?php $config = (new \LaravelPWA\Services\ManifestService)->generate(); echo $__env->make( 'laravelpwa::meta' , ['config' => $config])->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
       
        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('materias.index')->html();
} elseif ($_instance->childHasBeenRendered('8y1ZQv2')) {
    $componentId = $_instance->getRenderedChildComponentId('8y1ZQv2');
    $componentTag = $_instance->getRenderedChildComponentTagName('8y1ZQv2');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('8y1ZQv2');
} else {
    $response = \Livewire\Livewire::mount('materias.index');
    $html = $response->html();
    $_instance->logRenderedChild('8y1ZQv2', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?> 
<?php $__env->stopSection(); ?>

<?php $__env->startSection('plugins.Datatables', true); ?>

<?php $__env->startSection('css'); ?>
   
    <link rel="stylesheet" href="/css/admin_custom.css">
   <?php echo \Livewire\Livewire::styles(); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
  <?php echo \Livewire\Livewire::scripts(); ?>

  <script>

    $(document).ready( function () {
        $('#tablem').DataTable();
    } );
  </script>
    
<?php $__env->stopSection(); ?>


<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\atlasescolar\resources\views/admin/materias/index.blade.php ENDPATH**/ ?>