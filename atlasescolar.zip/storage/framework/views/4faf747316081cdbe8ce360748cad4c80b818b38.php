
        <div class="container-fluid">
            <div class="row">
                <div class="col-12">
           
                    <div class="card card-primary">
                        <div class="row  align-items-center">
        
                            <div class="card-body">
                                <div class="row">
                                    <div class="col">   
                                        <h3 class=" text-center text-info"> 
                                            <strong> 
                                                <i class="fas fa-school"></i> <span>Curso <?php echo e($personalizado->name); ?> </span>
                                           </strong>
                                       </h3>         
                                    </div> 
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                  
                        <div class="col-6">
                            <div class="card card-primary">
                                <div class="row  align-items-center">
                                    <div class="card-body">
                                        <div class="row">
                                            <div class="col">
                                                <h3 class="text-center text-warning " > <i class="fas fa-user-friends"></i><strong> Compañeros </strong> </h3>
                                                <div class="table-responsive">
                                                    <table id="tablem" class="table aling-middle">
                                    
                                                        <thead>
                                                            <tr>
                                                                
                                                                <th class="text-left" >Nombre</th>
                                                                <th class="text-left" >Apellido</th>
                                                                <th class="text-left" >telefono</th>
                                                                <th class="text-left" >Correo</th>
                                                             
                                                            </tr>
                                                        </thead>
                                                        <tbody>
                                                            <?php $__currentLoopData = $companero; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $alumno): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <tr>
                                                                <td><?php echo e($alumno->name); ?></td>
                                                                <td><?php echo e($alumno->last_name); ?></td>
                                                                <td><?php echo e($alumno->telephone); ?></td>
                                                                <td><?php echo e($alumno->email); ?></td>
                                    
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                           
                                                        </tbody>
                                                    </table>
                                                  
                                                </div>
                                            
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-6">
                            <div class="card card-primary">
                                <div class="row  align-items-center">
                                    <div class="card-body">
                                        <div class="row">
                                            <div class="col">
                                               
                                                <div class="table-responsive">
                                                    <table id="tablem" class="table aling-middle">
                                    
                                                        <thead>
                                                            <tr>
                                                                
                                                                
                                                                <th class="text-left" >Materia</th>
                                            
                                                                <th class="text-left" >Profesor</th>
                                                                <th class="text-left" >Correo</th>
                                                                <th class="text-left" >Telefono</th>
                                                                <th class="text-center" >Lecciones</th>
                                                               
                                                             
                                                            </tr>
                                                        </thead>
                                                        <tbody>
                                                            <?php $__currentLoopData = $Prof_materias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $profesor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <tr>
                                                               
                                                                <td><?php echo e($profesor->materia); ?></td>
                                                             
                                                                <td> <?php echo e($profesor->apellido); ?> <?php echo e($profesor->profesor); ?></td>
                                                                <td> <?php echo e($profesor->correo); ?></td>
                                                                <td> <?php echo e($profesor->telefono); ?></td>
                                                                <td class="text-center"> <button wire:click="leccionesA(<?php echo e($profesor->materiaID); ?>, <?php echo e($profesor->profesorId); ?> )" type="submit" class="btn btn-outline-primary "><i class="fas fa-eye"></i></button></td>
                                                               
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                           
                                                        </tbody>
                                                    </table>
                                                  
                                                </div>
                                            
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
       
              
            </div>
        </div>
<?php /**PATH C:\xampp\htdocs\atlasescolar\resources\views/livewire/alumno/vista/informacion.blade.php ENDPATH**/ ?>