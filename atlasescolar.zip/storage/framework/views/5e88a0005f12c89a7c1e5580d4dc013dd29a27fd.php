<?php $__env->startSection('title', 'Dashboard'); ?>

<?php $__env->startSection('content_header'); ?>
<?php $config = (new \LaravelPWA\Services\ManifestService)->generate(); echo $__env->make( 'laravelpwa::meta' , ['config' => $config])->render(); ?>
    <h1 class="text-center text-info "> <strong> Panel administrador</strong></h1>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('profesor-index')): ?>
<section class="content">
    <div class="container-fluid">
        <div class="row">

            

            <div class="col-4">
                <div class="card card-primary">
                    <div class="row  align-items-center">
                        <div class="card-body">
                            <div class="row">
                                <div class="col">
                                        <?php $__currentLoopData = $materias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <h3 class="text-center text-warning " > <strong><?php echo e($item->total); ?> Materias Asignadas  </strong> <i class="fas fa-calculator"></i> </h3>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-4">
                <div class="card card-primary">
                    <div class="row  align-items-center">
                        <div class="card-body">
                            <div class="row">
                                <div class="col">
                                        <?php $__currentLoopData = $cursos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <h3 class="text-center text-danger " > <strong><?php echo e($item->total); ?> Curso Asignados </strong> <i class="fas fa-school"></i>  </h3>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-4">
                <div class="card card-primary">
                    <div class="row  align-items-center">
                        <div class="card-body">
                            <div class="row">
                                <div class="col">
                                        <?php $__currentLoopData = $alumnos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <h3 class="text-center text-success " > <strong><?php echo e($item->total); ?> Alumnos Asignados </strong> <i class="fas fa-user-friends"></i> </h3>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
          
        </div>
    </div>
</section>

<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="/css/admin_custom.css">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script> console.log('Hi!'); </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\atlasescolar\resources\views/home.blade.php ENDPATH**/ ?>