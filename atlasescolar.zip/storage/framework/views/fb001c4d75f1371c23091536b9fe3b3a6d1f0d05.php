

 <div class="row">

    <?php echo $__env->make("livewire.alumno.$view", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <?php echo $__env->make("livewire.alumno.table", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
 </div>



<?php /**PATH C:\xampp\htdocs\atlasescolar\resources\views/livewire/Alumno/index.blade.php ENDPATH**/ ?>