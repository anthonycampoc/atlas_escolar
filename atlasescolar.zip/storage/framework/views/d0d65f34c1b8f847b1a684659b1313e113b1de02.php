<div class="card-body">
    <div class="row">
        <div class="col">
          <input type="text" wire:model= "name" name="name" class="form-control" placeholder="Nombre" aria-label="Nombre">
        </div>
        <div class="col">
          <input type="text" wire:model = "description" name="description" class="form-control" placeholder="Descripcion" aria-label="Descripcion">
        </div>
      </div> 
</div><?php /**PATH C:\xampp\htdocs\atlasescolar\resources\views/livewire/materias/form.blade.php ENDPATH**/ ?>