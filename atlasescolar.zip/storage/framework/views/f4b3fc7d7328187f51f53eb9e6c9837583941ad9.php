

<?php $__env->startSection('title', 'Dashboard'); ?>

<?php $__env->startSection('content_header'); ?>

<hr>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('alumno-index')): ?>
<section class="content">
    <div class="container-fluid">
        <div class="row">

            
              
                    <div class="col-6">
                        <div class="card card-primary">
                            <div class="row  align-items-center">
                                <div class="card-body">
                                    <div class="row">
                                        <div class="col">
                                            <h3 class="text-center text-warning " > <strong> Compañeros </strong> </h3>
                                            <div class="table-responsive">
                                                <table id="tablem" class="table table-bordered">
                                
                                                    <thead>
                                                        <tr>
                                                            
                                                            <th class="text-center" >Nombre</th>
                                                            <th class="text-center" >Apellido</th>
                                                            <th class="text-center" >telefono</th>
                                                            <th class="text-center" >Correo</th>
                                                         
                                                        </tr>
                                                    </thead>
                                                    <tbody>
                                                        <?php $__currentLoopData = $companero; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $alumno): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <tr>
                                                            <td><?php echo e($alumno->name); ?></td>
                                                            <td><?php echo e($alumno->last_name); ?></td>
                                                            <td><?php echo e($alumno->telephone); ?></td>
                                                            <td><?php echo e($alumno->email); ?></td>
                                
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                       
                                                    </tbody>
                                                </table>
                                              
                                            </div>
                                        
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-6">
                        <div class="card card-primary">
                            <div class="row  align-items-center">
                                <div class="card-body">
                                    <div class="row">
                                        <div class="col">
                                            <h3 class="text-center text-warning " > <strong> Materias y Profesores </strong> </h3>
                                            <div class="table-responsive">
                                                <table id="tablem" class="table table-bordered">
                                
                                                    <thead>
                                                        <tr>
                                                            
                                                            <th class="text-center" >Materia</th>
                                                            <th class="text-center" >Profesor</th>
                                                           
                                                         
                                                        </tr>
                                                    </thead>
                                                    <tbody>
                                                        <?php $__currentLoopData = $Prof_materias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $profesor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <tr>
                                                            <td><?php echo e($profesor->materia); ?></td>
                                                            <td><?php echo e($profesor->profesor); ?></td>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                       
                                                    </tbody>
                                                </table>
                                              
                                            </div>
                                        
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
   
          
        </div>
    </div>
</section>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="/css/admin_custom.css">
    <?php echo \Livewire\Livewire::styles(); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script> console.log('Hi!'); </script>
    <?php echo \Livewire\Livewire::scripts(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\atlasescolar\resources\views/livewire/alumno/vista.blade.php ENDPATH**/ ?>