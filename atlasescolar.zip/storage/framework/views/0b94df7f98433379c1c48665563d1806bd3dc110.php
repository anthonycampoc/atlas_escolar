

<?php $__env->startSection('title', 'Curso'); ?>

<?php $__env->startSection('content_header'); ?>
  <hr>
  <?php $config = (new \LaravelPWA\Services\ManifestService)->generate(); echo $__env->make( 'laravelpwa::meta' , ['config' => $config])->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
       
        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('grupo.index')->html();
} elseif ($_instance->childHasBeenRendered('4LH4glF')) {
    $componentId = $_instance->getRenderedChildComponentId('4LH4glF');
    $componentTag = $_instance->getRenderedChildComponentTagName('4LH4glF');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('4LH4glF');
} else {
    $response = \Livewire\Livewire::mount('grupo.index');
    $html = $response->html();
    $_instance->logRenderedChild('4LH4glF', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?> 
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="/css/admin_custom.css">
    <?php echo \Livewire\Livewire::styles(); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<?php echo \Livewire\Livewire::scripts(); ?>

<script>
  
  $(document).ready( function () {
      $('#tablec').DataTable();
  } );
</script>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\atlasescolar\resources\views/admin/grupo/index.blade.php ENDPATH**/ ?>