<div class="container-fluid">
    <div class="row">
        <div class="col-12">
            <div class="card card-primary">
                <div class="row  align-items-center">

                    <div class="card-body">
                        <div class="row">
                            <div class="col">   
                                <h3 class=" text-center text-warning"> 
                                    <strong> 
                                        <?php $__currentLoopData = $materiaH; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $m): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <i class="fas fa-book-open"></i> <span>Lecciones de <?php echo e($m->nombreMateria); ?>  </span>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                      
                                   </strong>
                               </h3> 
                               
                               <div class="table-responsive">
                                <table class="table table-bordered">
                
                                    <thead>
                                        <tr>
                                            
                                            <th class="text-center" >Titulo</th>
                                            <th class="text-center" >Contenido</th>
                                            <th class="text-center" >Fecha Publicada</th>
                                            
                                            
                                        </tr>
                                    </thead>
                                    <tbody>
                                      <?php $__currentLoopData = $l; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($item->nombreLeccion); ?></td>
                                            <td><?php echo e($item->contenidoLeccion); ?></td>
                                            <td><?php echo e($item->fechaLeccion); ?></td>
                                           
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                               
                            </div> 
                        </div>

                      
                    </div>
                </div>
            </div>
        </div>
        
    </div>
</div>

<?php /**PATH C:\xampp\htdocs\atlasescolar\resources\views/livewire/alumno/vista/l.blade.php ENDPATH**/ ?>