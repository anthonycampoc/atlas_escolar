
 
 
   <div class="row">
      <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('grupo-asignacion')): ?>
         <?php echo $__env->make("livewire.grupo.asignacion.$view", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

         <?php echo $__env->make("livewire.grupo.asignacion.table", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
      <?php endif; ?>
   </div>   

 <?php /**PATH C:\xampp\htdocs\atlasescolar\resources\views/livewire/grupo/asignacion/index.blade.php ENDPATH**/ ?>