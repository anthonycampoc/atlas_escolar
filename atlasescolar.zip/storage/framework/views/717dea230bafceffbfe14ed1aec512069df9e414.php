

<?php $__env->startSection('title', 'Profesor'); ?>

<?php $__env->startSection('content_header'); ?>
  <hr>
  <?php $config = (new \LaravelPWA\Services\ManifestService)->generate(); echo $__env->make( 'laravelpwa::meta' , ['config' => $config])->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
       
        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('profesor.index')->html();
} elseif ($_instance->childHasBeenRendered('NRHtRoR')) {
    $componentId = $_instance->getRenderedChildComponentId('NRHtRoR');
    $componentTag = $_instance->getRenderedChildComponentTagName('NRHtRoR');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('NRHtRoR');
} else {
    $response = \Livewire\Livewire::mount('profesor.index');
    $html = $response->html();
    $_instance->logRenderedChild('NRHtRoR', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?> 
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="/css/admin_custom.css">
    <?php echo \Livewire\Livewire::styles(); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
  <?php echo \Livewire\Livewire::scripts(); ?>

    <script> console.log('Hi!'); </script>
  
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\atlasescolar\resources\views/admin/profesor/index.blade.php ENDPATH**/ ?>