



<div class="col-12">
    <div class="card card-primary">
        
        <div class="card-body">

            <div class="table-responsive">
                <table class="table table-bordered">

                    <thead>
                        <tr>
                            
                            <th class="text-center" >Nombre</th>
                            <th class="text-center" >Apellido</th>
                            <th class="text-center" >cedula</th>
                            <th class="text-center" >telefono</th>
                            <th class="text-center" >Estado</th>
                            <th class="text-center" >Correo</th>
                            <th class="text-center" >Acciones</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $profesores; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $profesor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($profesor->name); ?></td>
                            <td><?php echo e($profesor->number); ?></td>
                            <td><?php echo e($profesor->last_name); ?></td>
                            <td><?php echo e($profesor->telephone); ?></td>
                            <td><?php echo e($profesor->status); ?></td>
                            <td><?php echo e($profesor->email); ?></td>

                 
                            <td class="text-center">  
                                
                                    <button wire:click="view(<?php echo e($profesor->id); ?>)" type="submit" class="btn btn-outline-primary "><i class="fas fa-eye"></i></button>
                                    <button wire:click="edit(<?php echo e($profesor->id); ?>)" type="submit" class="btn btn-outline-primary "><i class="fas fa-edit"></i></button>
                                    <button wire:click="destroy(<?php echo e($profesor->id); ?>)" type="submit" class="btn btn-outline-danger"><i class="fas fa-trash-alt"></i></button></td>
                            
                        </tr>
                            
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                       
                    </tbody>
                </table>
              
            </div>
        </div>
        <div class="card-footer clearfix">
            <?php echo e($profesores->links()); ?>

        </div>
    </div>
</div><?php /**PATH C:\xampp\htdocs\atlasescolar\resources\views/livewire/profesor/table.blade.php ENDPATH**/ ?>