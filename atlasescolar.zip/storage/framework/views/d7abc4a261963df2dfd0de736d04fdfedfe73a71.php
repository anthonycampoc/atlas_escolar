

<?php $__env->startSection('title', 'Registro de usuario'); ?>

<?php $__env->startSection('content_header'); ?>
<section class="content-header">
    <div class="container-fluid">
        <div class="row mb-2">
            <div class="col-sm-6">
                <h1>Registro de usuario</h1>
            </div>
            <div class="col-sm-6">
                <ol class="breadcrumb float-sm-right">
                    <li class="breadcrumb-item"><a href="<?php echo e(route('home')); ?>">Inicio</a></li>
                    <li class="breadcrumb-item"><a href="<?php echo e(route('users.index')); ?>">Usuarios</a></li>
                    <li class="breadcrumb-item active">Registro de usuario</li>
                </ol>
            </div>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>


<?php if(count($errors) > 0): ?>
<div class="alert alert-danger" role="alert">
    <label>¡Vaya!</label> Hubo algunos problemas con su entrada. <br> <br>
    <ul>
        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li><?php echo e($error); ?></li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
</div>
<?php endif; ?>

<section class="content">
    <div class="container-fluid">
        <div class="row">

            

            <div class="col-12">
                <div class="card card-primary">
                    <div class="row  align-items-center">
                        <div class="col-8">
                            <a href="<?php echo e(route('users.index')); ?>" class="btn btn-warning ml-2 mt-2 mb-2"> <i class="fas fa-list"></i> Regresar a la lista</a>
                            

                        </div>
                        <div class="col-4">

                        </div>
                        
                    </div>
                    
                </div>
            </div>

            <div class="col-12">
                <div class="card card-primary">
                    
                    <div class="card-body">

                        <?php echo Form::open(array('route' => 'users.store','method'=>'POST')); ?>

                        <div class="row">
                            <div class="col-xs-12 col-sm-12 col-md-12">
                                <div class="form-group">
                                    <label>Nombre:</label>
                                    <?php echo Form::text('name', null, array('placeholder' => 'Nombre','class' =>
                                    'form-control')); ?>

                                </div>
                            </div>
                            <div class="col-xs-12 col-sm-12 col-md-12">
                                <div class="form-group">
                                    <label>Correo electrónico:</label>
                                    <?php echo Form::text('email', null, array('placeholder' => 'Correo electrónico','class' =>
                                    'form-control')); ?>

                                </div>
                            </div>
                            <div class="col-xs-12 col-sm-12 col-md-12">
                                <div class="form-group">
                                    <label>Contraseña:</label>
                                    <?php echo Form::password('password', array('placeholder' => 'Contraseña','class' =>
                                    'form-control')); ?>

                                </div>
                            </div>
                            <div class="col-xs-12 col-sm-12 col-md-12">
                                <div class="form-group">
                                    <label>Confirmar Contraseña:</label>
                                    <?php echo Form::password('confirm-password', array('placeholder' => 'Confirmar Contraseña','class' => 'form-control')); ?>

                                </div>
                            </div>
                            <div class="col-xs-12 col-sm-12 col-md-12">
                                <div class="form-group">
                                    <label>Rol:</label>
                                    <?php echo Form::select('roles[]', $roles,[], array('class' => 'form-control','multiple')); ?>

                                </div>
                            </div>
                            

                            <button type="submit" class="btn btn-primary mr-2">Registrar</button>
                            <a href="<?php echo e(route('users.index')); ?>" class="btn btn-light">
                                Cancelar
                            </a>

                        </div>
                        <?php echo Form::close(); ?>

                    </div>
                    <div class="card-footer clearfix">



                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
<link rel="stylesheet" href="/css/admin_custom.css">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<script>
    console.log('Hi!');

</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\atlasescolar\resources\views/users/create.blade.php ENDPATH**/ ?>