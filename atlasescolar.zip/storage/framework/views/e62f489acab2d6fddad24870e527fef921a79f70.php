<div>
    <?php if(session()->has('message')): ?>
        <div class="alert alert-success">
            <?php echo e(session('message')); ?>

        </div>
    <?php endif; ?>
</div>
    <div class="container-fluid">
        <?php if(count($errors) > 0): ?>
            <div class="alert alert-danger" role="alert">
                <label>¡Vaya!</label> Hubo algunos problemas con su entrada. <br> <br>
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        <?php endif; ?>
        <div class="row">
            <div class="col-12">
                <div class="card card-primary">
                   <h3 class="text-center text-success mt-1">  <strong> <i class="fas fa-book"></i> <span> Ingreso Alumno</span></strong></h3>
                    <div class="row  align-items-center">
                       
                       
                        

                        <?php echo $__env->make('livewire.alumno.form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                        <div class="col-8 ml-3 mb-1">
                            <button wire:click="store" type="submit" class="btn btn-outline-success mt-3"><i class="fas fa-save"></i> <span>Guardar</span> </button>    
                        </div>
                              
                    </div>
                    
                </div>
            </div>

        </div>
    </div>

    


<?php /**PATH C:\xampp\htdocs\atlasescolar\resources\views/livewire/alumno/create.blade.php ENDPATH**/ ?>