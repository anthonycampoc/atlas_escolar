

 <div class="row">

    <?php echo $__env->make("livewire.profesor.$view", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <?php echo $__env->make("livewire.profesor.table", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
 </div>



<?php /**PATH C:\xampp\htdocs\atlasescolar\resources\views/livewire/profesor/index.blade.php ENDPATH**/ ?>