

<?php $__env->startSection('title', 'Registrar rol'); ?>

<?php $__env->startSection('content_header'); ?>
<section class="content-header">
    <div class="container-fluid">
        <div class="row mb-2">
            <div class="col-sm-6">
                <h1>Registrar rol</h1>
            </div>
            <div class="col-sm-6">
                <ol class="breadcrumb float-sm-right">
                    <li class="breadcrumb-item"><a href="<?php echo e(route('home')); ?>">Inicio</a></li>
                    <li class="breadcrumb-item"><a href="<?php echo e(route('roles.index')); ?>">Roles</a></li>
                    <li class="breadcrumb-item active">Registrar rol</li>
                </ol>
            </div>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>


<?php if(count($errors) > 0): ?>
<div class="alert alert-danger" role="alert">
    <label>¡Vaya!</label> Hubo algunos problemas con su entrada. <br> <br>
    <ul>
        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li><?php echo e($error); ?></li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
</div>
<?php endif; ?>

<section class="content">
    <div class="container-fluid">
        <div class="row">

           
           

            <div class="col-12">
                <div class="card card-primary">
                    <div class="row  align-items-center">
                        <div class="col-8">
                            <a href="<?php echo e(route('roles.index')); ?>" class="btn btn-warning ml-2 mt-2 mb-2"> <i class="fas fa-list"></i> Regresar a la lista</a>
                            

                        </div>
                        <div class="col-4">

                        </div>
                        
                    </div>
                    
                </div>
            </div>

            <div class="col-12">
                <div class="card card-primary">

                    <div class="card-body">
                        <?php echo Form::open(array('route' => 'roles.store','method'=>'POST')); ?>

                        <div class="row">
                            <div class="col-xs-12 col-sm-12 col-md-12">
                                <div class="form-group">
                                    <label>Nombre:</label>
                                    <?php echo Form::text('name', null, array('placeholder' => 'Nombre','class' =>
                                    'form-control')); ?>

                                </div>
                            </div>
                            <div class="col-xs-12 col-sm-12 col-md-12">
                                <div class="form-group">
                                    <label>Permiso:</label>
                                    <br />
                                    <?php $__currentLoopData = $permission; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <label><?php echo e(Form::checkbox('permission[]', $value->id, false, array('class' => 'name'))); ?>

                                        <?php echo e($value->name); ?></label>
                                    <br />
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                            </div>
                            

                            <button type="submit" class="btn btn-primary mr-2">Registrar</button>
                            <a href="<?php echo e(route('roles.index')); ?>" class="btn btn-light">
                                Cancelar
                            </a>

                        </div>
                        <?php echo Form::close(); ?>


                    </div>
                    <div class="card-footer clearfix">

                        

                    </div>
                </div>
            </div>
        </div>
    </div>
</section>


<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
<link rel="stylesheet" href="/css/admin_custom.css">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<script>
    console.log('Hi!');

</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\atlasescolar\resources\views/roles/create.blade.php ENDPATH**/ ?>