<div class="col-12">
    <div class="card card-primary">
        
        <div class="card-body">

            <div class="table-responsive">
                <table id="tablem" class="table table-bordered">

                    <thead>
                        <tr>
                            
                            <th class="text-center" >Nombre</th>
                            <th class="text-center" >Apellido</th>
                            <th class="text-center" >cedula</th>
                            <th class="text-center" >telefono</th>
                            <th class="text-center" >Estado</th>
                            <th class="text-center" >Correo</th>
                            <th class="text-center" >Acciones</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $alumnos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $alumno): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($alumno->name); ?></td>
                            <td><?php echo e($alumno->number); ?></td>
                            <td><?php echo e($alumno->last_name); ?></td>
                            <td><?php echo e($alumno->telephone); ?></td>
                            <td><?php echo e($alumno->status); ?></td>
                            <td><?php echo e($alumno->email); ?></td>

                 
                            <td class="text-center"> 
                                <button wire:click="view(<?php echo e($alumno->id); ?>)" type="submit" class="btn btn-outline-primary "><i class="fas fa-eye"></i></button>
                                <button wire:click="edit(<?php echo e($alumno->id); ?>)" type="submit" class="btn btn-outline-primary "><i class="fas fa-edit"></i></button>
                                <button wire:click="destroy(<?php echo e($alumno->id); ?>)" type="submit" class="btn btn-outline-danger"><i class="fas fa-trash-alt"></i></button></td>
                            </tr>
                            
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                       
                    </tbody>
                </table>
              
            </div>
        </div>
        <div class="card-footer clearfix">
            <?php echo e($alumnos->links()); ?>

        </div>
    </div>
</div><?php /**PATH C:\xampp\htdocs\atlasescolar\resources\views/livewire/alumno/table.blade.php ENDPATH**/ ?>