
    <div class="container-fluid">
        <?php if(count($errors) > 0): ?>
            <div class="alert alert-danger" role="alert">
                <label>¡Vaya!</label> Hubo algunos problemas con su entrada. <br> <br>
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        <?php endif; ?>
        <div class="row">
            <div class="col-12">
                <div class="card card-primary">
                    <div class="row  align-items-center">
                        <div class="card-body">
                            <div class="row">
                                <div class="col">   
                                    <h3 class=" text-center text-warning"> 
                                        <strong> 
                                          <i class="fas fa-user-tie"></i>  <span> Agregar Leccion <?php echo e($leccionesM->name); ?> </span>
                                       </strong>
                                   </h3> 
                                   
                                                <?php echo $__env->make('livewire.grupo.asignacion.materiaform', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                   
                                    <div class="row mt-3">
                                        <div class="col">
                                            <button wire:click="store(<?php echo e($leccionesM->id); ?>)" type="submit" class="btn btn-outline-success mt-3"><i class="fas fa-save"></i> <span>Guardar</span> </button>  
                                        </div>
                                    </div>
    
                                    
                                </div> 
                            </div> 
                        </div>
                    </div>
                </div>
            </div>

        </div>
    </div>

    <?php /**PATH C:\xampp\htdocs\atlasescolar\resources\views/livewire/grupo/asignacion/materiaA.blade.php ENDPATH**/ ?>