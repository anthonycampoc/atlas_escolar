<div class="container-fluid">
    <div class="row">
        <div class="col-12">
            <div class="card card-primary">
                <div class="row  align-items-center">

                    <div class="card-body">
                        <div class="row">
                            <div class="col">   
                                <h3 class=" text-center text-warning"> 
                                    <strong> 
                                      <i class="fas fa-user-tie"></i>  <span>Leccion </span>
                                   </strong>
                               </h3> 
                               
                               <div class="table-responsive">
                                <table class="table table-bordered">
                
                                    <thead>
                                        <tr>
                                            
                                            <th class="text-center" >Titulo</th>
                                            <th class="text-center" >Contenido</th>
                                            <th class="text-center" >Fecha Publicada</th>
                                            <th class="text-center" >ACCIONES</th>
                                            
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__currentLoopData = $lecciones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($item->nLeccion); ?></td>
                                            <td><?php echo e($item->tarea); ?></td>
                                            <td><?php echo e($item->FD); ?></td>
                                            <td>
                                                <button wire:click="editleccion(<?php echo e($item->idleccion); ?>)" type="submit" class="btn btn-outline-primary "><i class="fas fa-edit"></i></button>
                                            </td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                               
                            </div> 
                        </div>

                        <div class="row mt-3">
                            <div class="col">
                                
                                <button wire:click="default" type="submit" class="btn btn-outline-secondary mt-3"> <i class="fas fa-long-arrow-alt-left"></i> <span>Cancelar</span> </button>  
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
    </div>
</div>



<?php /**PATH C:\xampp\htdocs\atlasescolar\resources\views/livewire/grupo/asignacion/leccion.blade.php ENDPATH**/ ?>