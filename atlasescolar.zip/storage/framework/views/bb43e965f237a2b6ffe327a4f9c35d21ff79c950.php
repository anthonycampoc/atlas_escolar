

<?php $__env->startSection('title', 'Alumno'); ?>

<?php $__env->startSection('content_header'); ?>
  <hr>
  <?php $config = (new \LaravelPWA\Services\ManifestService)->generate(); echo $__env->make( 'laravelpwa::meta' , ['config' => $config])->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
       
        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('alumno.index')->html();
} elseif ($_instance->childHasBeenRendered('BRctdX4')) {
    $componentId = $_instance->getRenderedChildComponentId('BRctdX4');
    $componentTag = $_instance->getRenderedChildComponentTagName('BRctdX4');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('BRctdX4');
} else {
    $response = \Livewire\Livewire::mount('alumno.index');
    $html = $response->html();
    $_instance->logRenderedChild('BRctdX4', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?> 
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="/css/admin_custom.css">
   <?php echo \Livewire\Livewire::styles(); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<?php echo \Livewire\Livewire::scripts(); ?>

<script>
  
  $(document).ready( function () {
      $('#tablem').DataTable();
  } );
</script>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\atlasescolar\resources\views/admin/alumno/index.blade.php ENDPATH**/ ?>