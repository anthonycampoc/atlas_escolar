

 <div class="row">
   <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('role-edit')): ?>
    <?php echo $__env->make("livewire.grupo.$view", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
      <?php echo $__env->make("livewire.grupo.table", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php endif; ?>
 </div>



<?php /**PATH C:\xampp\htdocs\atlasescolar\resources\views/livewire/grupo/index.blade.php ENDPATH**/ ?>