<div class="container-fluid">
    <div class="row">
        <div class="col-8">
            <div class="card card-primary">
                   <h3 class="text-center text-warning mt-1">  <strong> <i class="fas fa-book"></i> <span> Actualizar Alumno</span></strong></h3>
                <div class="row  align-items-center">
                       
                        <?php echo $__env->make('livewire.profesor.form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                        <div class="col-8 ml-3 mb-1">
                            <button wire:click="update" type="submit" class="btn btn-outline-warning mt-3"> <i class="fas fa-edit"></i> <span> Actualizar </span> </button>

                            <button wire:click="default" id="refresh" type="submit" class="btn btn-outline-secondary mt-3"> <i class="fas fa-long-arrow-alt-left"></i> <span>Cancelar</span> </button>   
                        </div>
                              
                </div>
                    
             </div>
        </div>

        <div class="col-4">
           
            <div class="card card-primary">
                <div class="row  align-items-center">

                    <div class="card-body">
                        <div class="row">
                            <div class="col">
                                    <?php if($idalumnado->asignacion == 1): ?>
                                        <h4 class=" text-center text-info"><?php echo e($idalumnado->name); ?> <?php echo e($idalumnado->last_name); ?> YA TIENE UN CURSO ASIGNADO</h4>
                                    <?php else: ?>
                                    <label for="">Listado de cursos</label>
                                    <div class="table-responsive">
                                        <table class="table aling-middle">
                                            <thead>
                                                <tr>
                                                    <th>Cursos</th>
                                                    <th></th>
                                                    <th>Accion</th>
                                                </tr>
                                            </thead>
    
                                            <tbody>
                                                <?php $__currentLoopData = $cursoM; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item2): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <tr>
                                                    <td><?php echo e($item2->name); ?></td>
                                                    <td></td>
                                                    <td><button wire:click="addmateriaA(<?php echo e($item2->id); ?>,<?php echo e($idalumnado->id); ?>)" type="submit" class="btn btn-outline-success"><i class="fas fa-check-circle"></i></button></td>
                                                </tr>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            
                                            </tbody>
                                        </table>
                                    </div>
                                    <?php endif; ?>  
                            </div> 
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>




<?php /**PATH C:\xampp\htdocs\atlasescolar\resources\views/livewire/alumno/edit.blade.php ENDPATH**/ ?>