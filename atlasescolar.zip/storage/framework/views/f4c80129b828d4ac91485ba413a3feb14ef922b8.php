<div>
    <h1>lecciones</h1>
</div>
<?php /**PATH C:\xampp\htdocs\atlasescolar\resources\views/livewire/leccion/index.blade.php ENDPATH**/ ?>