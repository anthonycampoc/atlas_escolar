<div class="col-12">
    <div class="card card-primary">
        
        <div class="card-body">

            <div class="table-responsive">
                <table id="tablem" class="table table-bordered">

                    <thead>
                        <tr>
                            
                            <th class="text-center" >Nombre</th>
                            <th class="text-center" >Descripcion</th>
                            <th class="text-center" >Acción</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $materias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $materia): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($materia->name); ?></td>
                            <td><?php echo e($materia->description); ?></td>
                        
                                <td class="text-center"> <button wire:click="edit(<?php echo e($materia->id); ?>)" type="submit" class="btn btn-outline-primary "><i class="fas fa-edit"></i></button>
                              <button wire:click="destroy(<?php echo e($materia->id); ?>)" type="submit" class="btn btn-outline-danger"><i class="fas fa-trash-alt"></i></button></td>
                       
                        </tr>
                            
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                       
                    </tbody>
                </table>
              
            </div>
        </div>
        <div class="card-footer clearfix">
           
        </div>
    </div>
</div>

<?php /**PATH C:\xampp\htdocs\atlasescolar\resources\views/livewire/materias/table.blade.php ENDPATH**/ ?>