<div>
    <?php if(session()->has('message')): ?>
        <div class="alert alert-success">
            <?php echo e(session('message')); ?>

        </div>
    <?php endif; ?>
</div> <?php /**PATH C:\xampp\htdocs\atlasescolar\resources\views/livewire/grupo/asignacion/create.blade.php ENDPATH**/ ?>