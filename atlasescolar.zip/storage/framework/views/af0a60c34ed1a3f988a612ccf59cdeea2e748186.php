<div>
<h1>lkjljk</h1>
</div>
<?php /**PATH C:\xampp\htdocs\atlasescolar\resources\views/livewire/alumno/index.blade.php ENDPATH**/ ?>